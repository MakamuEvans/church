<section id="featured" class="bg">
    <!-- start slider -->


    <!-- start slider -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!-- Slider -->
                <div id="main-slider" class="main-slider flexslider">
                    <ul class="slides">
                        <li>
                            <img src="<?php echo e(url('images/slider/church.jpg')); ?>" style="width: 100%;height: auto;max-height: 500px" alt="" />
                            <div class="flex-caption">
                                <h3>Title 1</h3>
                                <p>Duis fermentum auctor ligula ac malesuada. Mauris et metus odio, in pulvinar urna</p>
                                <a href="#" class="btn btn-theme">Learn More</a>
                            </div>
                        </li>
                        <li>
                            <img src="<?php echo e(url('images/slider/speech.jpg')); ?>" style="width: 100%;height: auto;max-height: 500px" alt="" />
                            <div class="flex-caption">
                                <h3>Title 2</h3>
                                <p>Sodales neque vitae justo sollicitudin aliquet sit amet diam curabitur sed fermentum.</p>
                                <a href="#" class="btn btn-theme">Learn More</a>
                            </div>
                        </li>
                        <li>
                            <img src="<?php echo e(url('images/slider/usfw1.jpg')); ?>" style="width: 100%;height: auto;max-height: 500px" alt="" />
                            <div class="flex-caption">
                                <h3>Title 3</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit donec mer lacinia.</p>
                                <a href="#" class="btn btn-theme">Learn More</a>
                            </div>
                        </li>
                    </ul>
                </div>
                <!-- end slider -->
            </div>
        </div>
    </div>


</section>