<?php $__env->startSection('content'); ?>
    <section id="inner-headline">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="breadcrumb" style="background-color: #354e9d">
                        <li><a href="#"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
                        <li><a href="#">Administration</a><i class="icon-angle-right"></i></li>
                        <li class="active">USFW</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section id="content">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        <h3>USFW</h3>
                        <div class="col-md-6">
                            <img src="<?php echo e(url('images/photo.png')); ?>" height="auto" width="100%"  alt="logo">
                        </div>

                        <h4>CHAIRPERSON-FLORENCE LIHANDA</h4>
                        <p>
                        <blockquote>
                            <i class="fa fa-quote-left"></i> Lorem ipsum dolor sit amet, ei quod constituto qui. Summo labores expetendis ad quo, lorem luptatum et vis. No qui vidisse signiferumque...
                        </blockquote>

                        </p>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <img src="<?php echo e(url('images/ad/anno.jpg')); ?>" height="auto" width="100%" style="max-height: 400px;overflow-y: hidden;border-radius: 10px"  alt="logo">
                        </div>

                        <h4>VICE CHAIR-EVERLYNE ANNO</h4>
                        <p>
                        <blockquote>
                            <i class="fa fa-quote-left"></i> Lorem ipsum dolor sit amet, ei quod constituto qui. Summo labores expetendis ad quo, lorem luptatum et vis. No qui vidisse signiferumque...
                        </blockquote>

                        </p>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <img src="<?php echo e(url('images/photo.png')); ?>" height="auto" width="100%" style="max-height: 400px;overflow-y: hidden;border-radius: 10px"  alt="logo">
                        </div>

                        <h4>PASTOR –WILFREDA AGESA</h4>
                        <p>
                        <blockquote>
                            <i class="fa fa-quote-left"></i> Lorem ipsum dolor sit amet, ei quod constituto qui. Summo labores expetendis ad quo, lorem luptatum et vis. No qui vidisse signiferumque...
                        </blockquote>

                        </p>
                    </div>
                </div>

                <div class="col-lg-4">
                    <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

            </div>


        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>