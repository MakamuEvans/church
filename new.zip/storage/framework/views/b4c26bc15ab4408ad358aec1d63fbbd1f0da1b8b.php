<?php $__env->startSection('content'); ?>
    <section id="inner-headline">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="breadcrumb" style="background-color: #354e9d">
                        <li><a href="#"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
                        <li><a href="#">Services</a><i class="icon-angle-right"></i></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section id="content">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">

                        <div class="col-md-6">
                            <?php $__currentLoopData = $currentservice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="row faa">
                                    <h2 style="color: #354e9d">This Week</h2>
                                    <h3><i class="fa fa-clock"></i> <?php echo e($current->date); ?></h3>
                                    <div class="row" style="font-size: 20px">
                                        <b>TOPIC:</b><br>
                                        <?php echo e($current->topic); ?><br>
                                        <b>TEXT:</b><br>
                                        <i><?php echo e($current->verse); ?></i><br>
                                        <b>SPEAKER:</b><br>
                                        <?php echo e($current->speaker); ?><br>
                                        <b>SERVICE LEADER:</b><br>
                                        <?php echo e($current->leader); ?><br>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                            <div class="row">
                                <h3 style="color: #354e9d">Previous Sermons >></h3>
                                <?php $__currentLoopData = $allservices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div class="row" style="background-color: #354e9d; margin-bottom: 1%;border-radius: 10px;color: white">
                                        <b>Dated:</b><?php echo e($all->date); ?><br>
                                        <b>Topic</b><h2 style="color: white"><?php echo e($all->topic); ?></h2>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </div>

                        </div>
                        <div class="col-md-6" style="text-align: left;padding-left: 10%">
                            <div class="row">
                                <h2 style="color: #354e9d">Our Order of Services</h2>

                                9:15	-PRAISE AND WORSHIP<br>

                                9:30	-OPENING PRAYER
                                <div class="row" style="padding-left: 50px">
                                    -2 HYMNS ON THE BULLETIN<br>
                                    -SCRIPTURE READING<br>
                                    -ANNOUNCEMENTS<br>
                                    -INTROD. OF VISITORS<br>
                                    -PRAISE AND WORSHIP<br>
                                    -INTERCESSION BY<br>
                                    -SERMON: PST. COLLINS<br>
                                    -PASTORAL PRAYERS<br>
                                    -OFFERTORY<br>
                                    -CLOSING BENEDICTION<br>
                                    -VISITORS MEET LEADERS<br>
                                </div>


                            </div>
                            <div class="row" style="margin-top: 2%">
                                <h2 style="color: #354e9d">Our Weekly Program</h2>
                                <table class="table table-striped table-bordered">
                                    <thead>
                                    <tr bgcolor="black" style="color: white">

                                        <td>Day</td>
                                        <td>Time</td>
                                        <td>Event</td>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Monday</td>
                                        <td>5:00pm-6:00pm</td>
                                        <td>Youth fellowship</td>
                                    </tr>
                                    <tr>
                                        <td>Tuesday</td>
                                        <td>10:00 am-2:00pm</td>
                                        <td>Pastoral counseling</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

            </div>


        </div>
    </section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>