<aside class="right-sidebar">


    <div class="widget">
        <h5 class="widgetheading" style="color: #354e9d">Latest Services</h5>
        <ul class="recent">
            <?php $__currentLoopData = $ibada; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li>
                    <img src=<?php echo e(url("img/dummies/blog/65x65/thumb1.jpg")); ?> class="pull-left" alt="" />
                    <h6><a href="#" style="color: #354e9d">Topic :<?php echo e($all->topic); ?></a></h6>
                    <p>
                        <b>Verse:</b><?php echo e($all->verse); ?>

                        <b>Speaker:</b> <?php echo e($all->speaker); ?>

                    </p>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    </div>

    <div class="widget">
        <h5 class="widgetheading" style="color: #354e9d">Social Interactions</h5>
        <ul class="cat">
            <li><i class="fa fa-angle-right"></i><a href="#">Facebook</a></li>
            <li><i class="fa fa-angle-right"></i><a href="#">Twitter</a></li>

        </ul>
    </div>

</aside>