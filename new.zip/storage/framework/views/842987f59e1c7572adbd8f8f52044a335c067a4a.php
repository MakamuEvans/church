<?php $__env->startSection('content'); ?>
    <div class="row" style="height: auto;" xmlns="http://www.w3.org/1999/html">
        <?php echo $__env->make('slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div class="col-md-10 col-md-offset-1" style="text-align: center;box-shadow: 2px 2px 5px #333;">
        <div class="row">

        <div class="col-md-7 faa" style="text-align: left;margin: 2%">

            <div class="row" style="padding-left: 6%;padding-right: 3%;border-radius: 10px">
                <h2 style="color: skyblue">
                    <u>Kakamega Friends' Church</u>
                </h2>
                <h5>
                   Kakamega Friends' Church is a Quaker Church founded in 1981 as EAYM.<br>
                    It is Located in Kenya, Kakamega County and Shirere ward, Amalemba Village.<br>
                    It has a population of 1,000 members with a residential Pastor at the compound.<br>
                    Within the Compound, we have Gorge Fox Resource centre and Kakamega Orphanage Center.
                    We believe in Quakers doctrine headed by Gorge Fox as our founder.
                </h5>
                    <h2 style="color: skyblue">
                        Our Motto
                    </h2>
                    <h5>
                       Commitment and service in the Church
                    </h5>
                    <h2 style="color: skyblue">
                    Reach us.
                    </h2>
                <h5>
                    <i class="fa fa-thumb-tack"style="margin-right: 2%"></i> P.o. Box 465 Kakamega 50100<br><br>
                    <i class="fa fa-thumb-tack"style="margin-right: 2%"></i>Email: info@kakamegafriends.co.ke

                </h5>
            </div>
            <hr style="color: skyblue">
        </div>
            <div class="col-md-4 faa ht" style="text-align: left;margin: 2%">
                <div class="row" style="margin: 2%">
                    <h2 style="color: skyblue"><u>Our Services</u></h2>
                    <h3 style="color: skyblue">This Week's Service</h3>
                    <h5>
                        <b>TOPIC:</b>
                        RIDING ON A PERSONAL TICKET IN THE KINGDOM
                        <b>TEXT:</b>
                        ROMANS 16:1-16
                        <b>SPEAKER</b>
                        : PST COLLINS INDECHE
                        <b>SERVICE LEADER:</b>
                        ASERI DICKSON

                    </h5>

                    <hr>
                    <div class="row" style="margin: 2%">

                        <h3 style="color: skyblue">Date</h3>
                        <h5>
                            <b>TOPIC:</b>
                            RIDING ON A PERSONAL TICKET IN THE KINGDOM
                            <b>TEXT:</b>
                            ROMANS 16:1-16
                            <b>SPEAKER</b>
                            : PST COLLINS INDECHE
                            <b>SERVICE LEADER:</b>
                            ASERI DICKSON

                        </h5>
                    </div>

                        <hr>
                    <div class="row" style="margin: 2%">
                            <h3 style="color: skyblue">Date</h3>
                        <h5>
                            <b>TOPIC:</b>
                            RIDING ON A PERSONAL TICKET IN THE KINGDOM
                            <b>TEXT:</b>
                            ROMANS 16:1-16
                            <b>SPEAKER</b>
                            : PST COLLINS INDECHE
                            <b>SERVICE LEADER:</b>
                            ASERI DICKSON

                        </h5>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>